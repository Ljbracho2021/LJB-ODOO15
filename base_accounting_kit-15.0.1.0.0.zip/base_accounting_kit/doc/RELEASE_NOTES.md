## Module <base_accounting_kit>

#### 06.10.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 accounting

